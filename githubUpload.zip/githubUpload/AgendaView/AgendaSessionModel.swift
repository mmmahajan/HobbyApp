/* 
Copyright (c) 2017 Swift Models Generated from JSON powered by http://www.json4swift.com

Permission is hereby granted, free of charge, to any person obtaining a copy of this software and associated documentation files (the "Software"), to deal in the Software without restriction, including without limitation the rights to use, copy, modify, merge, publish, distribute, sublicense, and/or sell copies of the Software, and to permit persons to whom the Software is furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY, FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM, OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE SOFTWARE.
*/

import Foundation
 
/* For support, please feel free to contact me at https://www.linkedin.com/in/syedabsar */

public class AgendaSessionModel {
	public var session_id : Int?
	public var session_name : String?
	public var session_speaker_name : String?
	public var session_date : String?
	public var session_day : String?
	public var session_start_time : String?
	public var session_end_time : String?
	public var session_location : String?
	public var session_lat : String?
	public var session_long : String?
	public var session_description : String?
	public var session_rateing : String?
	public var session_rate_status : String?
	public var session_image : String?
	public var session_vedio : String?

/**
    Returns an array of models based on given dictionary.
    
    Sample usage:
    let session_list = Session.modelsFromDictionaryArray(someDictionaryArrayFromJSON)

    - parameter array:  NSArray from JSON dictionary.

    - returns: Array of Session Instances.
*/
    public class func modelsFromDictionaryArray(array:NSArray) -> [AgendaSessionModel]
    {
        var models:[AgendaSessionModel] = []
        for item in array
        {
            models.append(AgendaSessionModel(dictionary: item as! NSDictionary)!)
        }
        return models
    }

/**
    Constructs the object based on the given dictionary.
    
    Sample usage:
    let session = Session(someDictionaryFromJSON)

    - parameter dictionary:  NSDictionary from JSON.

    - returns: Session Instance.
*/
	required public init?(dictionary: NSDictionary) {

		session_id = dictionary["session_id"] as? Int
		session_name = dictionary["session_name"] as? String
		session_speaker_name = dictionary["session_speaker_name"] as? String
		session_date = dictionary["session_date"] as? String
		session_day = dictionary["session_day"] as? String
		session_start_time = dictionary["session_start_time"] as? String
		session_end_time = dictionary["session_end_time"] as? String
		session_location = dictionary["session_location"] as? String
		session_lat = dictionary["session_lat"] as? String
		session_long = dictionary["session_long"] as? String
		session_description = dictionary["session_description"] as? String
		session_rateing = dictionary["session_rateing"] as? String
		session_rate_status = dictionary["session_rate_status"] as? String
		session_image = dictionary["session_image"] as? String
		session_vedio = dictionary["session_vedio"] as? String
	}

		
/**
    Returns the dictionary representation for the current instance.
    
    - returns: NSDictionary.
*/
	public func dictionaryRepresentation() -> NSDictionary {

		let dictionary = NSMutableDictionary()

		dictionary.setValue(self.session_id, forKey: "session_id")
		dictionary.setValue(self.session_name, forKey: "session_name")
		dictionary.setValue(self.session_speaker_name, forKey: "session_speaker_name")
		dictionary.setValue(self.session_date, forKey: "session_date")
		dictionary.setValue(self.session_day, forKey: "session_day")
		dictionary.setValue(self.session_start_time, forKey: "session_start_time")
		dictionary.setValue(self.session_end_time, forKey: "session_end_time")
		dictionary.setValue(self.session_location, forKey: "session_location")
		dictionary.setValue(self.session_lat, forKey: "session_lat")
		dictionary.setValue(self.session_long, forKey: "session_long")
		dictionary.setValue(self.session_description, forKey: "session_description")
		dictionary.setValue(self.session_rateing, forKey: "session_rateing")
		dictionary.setValue(self.session_rate_status, forKey: "session_rate_status")
		dictionary.setValue(self.session_image, forKey: "session_image")
		dictionary.setValue(self.session_vedio, forKey: "session_vedio")

		return dictionary
	}

}
