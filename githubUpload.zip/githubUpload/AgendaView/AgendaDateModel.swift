
import Foundation
 
/* For support, please feel free to contact me at https://www.linkedin.com/in/syedabsar */

public class AgendaDateModel {
	public var sessiondate : String?
	public var session_schedule_status : String?
	public var update_count : Int?
	public var session : Array<AgendaSessionModel>?

/**
    Returns an array of models based on given dictionary.
    
    Sample usage:
    let data_list = Data.modelsFromDictionaryArray(someDictionaryArrayFromJSON)

    - parameter array:  NSArray from JSON dictionary.

    - returns: Array of Data Instances.
*/
    public class func modelsFromDictionaryArray(array:NSArray) -> [AgendaDateModel]
    {
        var models:[AgendaDateModel] = []
        for item in array
        {
            models.append(AgendaDateModel(dictionary: item as! NSDictionary)!)
        }
        return models
    }

/**
    Constructs the object based on the given dictionary.
    
    Sample usage:
    let data = Data(someDictionaryFromJSON)

    - parameter dictionary:  NSDictionary from JSON.

    - returns: Data Instance.
*/
	required public init?(dictionary: NSDictionary) {

		sessiondate = dictionary["sessiondate"] as? String
		session_schedule_status = dictionary["session_schedule_status"] as? String
		update_count = dictionary["update_count"] as? Int
		if (dictionary["session"] != nil) { session = AgendaSessionModel.modelsFromDictionaryArray(array: dictionary["session"] as! NSArray) }
	}

		
/**
    Returns the dictionary representation for the current instance.
    
    - returns: NSDictionary.
*/
	public func dictionaryRepresentation() -> NSDictionary {

		let dictionary = NSMutableDictionary()

		dictionary.setValue(self.sessiondate, forKey: "sessiondate")
		dictionary.setValue(self.session_schedule_status, forKey: "session_schedule_status")
		dictionary.setValue(self.update_count, forKey: "update_count")

		return dictionary
	}

}
