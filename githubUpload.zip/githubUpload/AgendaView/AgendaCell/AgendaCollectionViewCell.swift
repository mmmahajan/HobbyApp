//
//  AgendaCollectionViewCell.swift
//  Marico
//
//  Created by Admin on 06/09/17.
//  Copyright © 2017 Admin. All rights reserved.
//

import UIKit

class AgendaCollectionViewCell: UICollectionViewCell {

    @IBOutlet weak var bottomLabel: UILabel!
    @IBOutlet weak var agendaDateLabel: UILabel!
    override func awakeFromNib() {
        super.awakeFromNib()
        // Initialization code
    }

}
