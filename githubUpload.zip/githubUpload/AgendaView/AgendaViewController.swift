//
//  AgendaViewController.swift
//  Marico
//
//  Created by Admin on 06/09/17.
//  Copyright © 2017 Admin. All rights reserved.
//

import UIKit
import Alamofire

class AgendaViewController: BaseViewController, UICollectionViewDataSource,UICollectionViewDelegate, UICollectionViewDelegateFlowLayout, UIPageViewControllerDelegate, UIPageViewControllerDataSource, AgendaSessionViewControllerDelegate {
    
    @IBOutlet weak var backButton: UIButton!
    @IBOutlet weak var menuButton: UIButton!
    @IBOutlet weak var agendaTopCollectionView: UICollectionView!
    var eventId = ""
    var arrOfLine = [String]()
    var menuName = ""
    var viewControllers = [UIViewController]()
    var pageViewController : UIPageViewController!
    var index = 0
    var fromSideMenu: Bool = true
    var agendaDataFeedModelArray = [AgendaDateModel]()
    
    override func viewDidLoad() {
        super.viewDidLoad()
        self.getAgenda()
        hideNavigationBar()
        let nib = UINib(nibName: "AgendaCollectionViewCell", bundle: nil)
        agendaTopCollectionView?.register(nib, forCellWithReuseIdentifier: "agendaCell")
        agendaTopCollectionView.delegate = self
        agendaTopCollectionView.dataSource = self
        hideShowBackMenuButton()
        // Do any additional setup after loading the view.
    }
    
    override func viewWillAppear(_ animated: Bool) {
        menuButton.addTarget(self.revealViewController(), action: #selector(SWRevealViewController.revealToggle(_:)), for: .touchUpInside)
        self.revealViewController().tapGestureRecognizer()
        self.revealViewController().panGestureRecognizer()
    }
    
    func hideShowBackMenuButton() {
        if fromSideMenu {
            backButton.isHidden = true
        } else {
            menuButton.isHidden = true
        }
    }
    
    @IBAction func backAction(_ sender: Any) {
        navigationController?.popViewController(animated: true)
    }
    
    @IBAction func notificationAction(_ sender: Any) {
        navigationController?.pushViewController(NotificationViewController(nibName: NOTIFICATION_VIEW_CONTROLLER, bundle: nil), animated: true)
    }
    
    func pageController() {
        pageViewController  = UIPageViewController()
        pageViewController.delegate = self
        pageViewController.dataSource = self
        let startingViewController = self.viewControllers[0]
        
        let viewControllers : NSArray = [startingViewController]
        pageViewController.setViewControllers(viewControllers as? [UIViewController], direction: .forward, animated: false, completion: nil)
        pageViewController.view.frame = CGRect.init(x: 0, y: 114, width: self.view.frame.size.width, height: self.view.frame.size.height-80)
        
        self.addChildViewController(pageViewController)
        self.view.addSubview(pageViewController.view)
        pageViewController.didMove(toParentViewController: self)
    }
    
    //Get Agenda
    func getAgenda() {
        
        NetworkHelper().request(.get, "GetSessions.php?eventid=\(self.getUserDefaults(key: EVENT_ID))&userid=\(self.getUserDefaults(key: USER_ID))", parameters: nil, headers: nil, onView: view, completion: { (response) in
            if let JSON = response as? [String: Any] {
                let message = JSON[MESSAGE] as? String
                let statusCode = JSON[STATUS_CODE] as? Int
                let successStatus = JSON["sucess"] as? String
                guard successStatus == TRUE else {
                    AppUtil.showMessage(message!, messageTitle: EMPTY_STRING, buttonTitle: OK)
                    return
                }
                if let data = JSON[DATA] as? NSArray {
                    self.agendaDataFeedModelArray = AgendaDateModel.modelsFromDictionaryArray(array: data)
                    for index in 0..<self.agendaDataFeedModelArray.count {
                        let eventAgendaSessionVC = AgendaSessionViewController()
                        eventAgendaSessionVC.arrOFSession = self.agendaDataFeedModelArray[index].session ?? []
                        eventAgendaSessionVC.delegate = self
                        eventAgendaSessionVC.pageIndex = index
                        eventAgendaSessionVC.menuName = self.menuName
                        eventAgendaSessionVC.eventId = self.eventId
                        self.viewControllers.append(eventAgendaSessionVC)
                        if index == 0 {
                            self.arrOfLine.append("YES")
                        } else {
                            self.arrOfLine.append("NO")
                        }
                    }
                    self.pageController()
                    self.agendaTopCollectionView.reloadData()
                }
            }
        }) { (error) in
            print(ERROR, error)
        }
    }
    
    func pageViewController(_ pageViewController: UIPageViewController, viewControllerBefore viewController: UIViewController) -> UIViewController? {
        let index : Int  = (viewController as! AgendaSessionViewController).pageIndex
        if index == 0  || index == NSNotFound {
            return nil
        }
        self.index = index - 1
        return self.viewControllers[self.index]
    }
    
    func pageViewController(_ pageViewController: UIPageViewController, viewControllerAfter viewController: UIViewController) -> UIViewController? {
        
        let index : Int  = (viewController as! AgendaSessionViewController).pageIndex
        if (index == NSNotFound) {
            return nil;
        }
        
        ///increment the index to get the viewController after the current index
        self.index = index + 1
        if (self.index == self.agendaDataFeedModelArray.count) {
            return nil;
        }
        return self.viewControllers[self.index]
    }
    
    func presentationCount(for pageViewController: UIPageViewController) -> Int {
        return agendaDataFeedModelArray.count
    }
    
    func presentationIndex(for pageViewController: UIPageViewController) -> Int {
        return 0
    }
    
    // CollectionView - DataSource
    public func collectionView(_ collectionView: UICollectionView, numberOfItemsInSection section: Int) -> Int {
        return agendaDataFeedModelArray.count
    }
    
    public func collectionView(_ collectionView: UICollectionView, cellForItemAt indexPath: IndexPath) -> UICollectionViewCell {
        let cell = collectionView.dequeueReusableCell(withReuseIdentifier: "agendaCell", for: indexPath) as! AgendaCollectionViewCell
        cell.agendaDateLabel.text = agendaDataFeedModelArray[indexPath.row].sessiondate!
        if arrOfLine[indexPath.row] == "NO" {
            cell.bottomLabel.backgroundColor = UIColor.clear
        } else {
            cell.bottomLabel.backgroundColor = UIColor.appBlueColor()
        }
        return cell
    }
    
    public func collectionView(_ collectionView: UICollectionView, layout collectionViewLayout: UICollectionViewLayout, sizeForItemAt indexPath: IndexPath) -> CGSize {
        // let cellWidth = screenWidth / 3.1; //Replace the divisor with the column count requirement. Make sure to have it in float.
        return CGSize(width: 100, height: 50);
    }
    
    //CollectionView Delegate Method
    public func collectionView(_ collectionView: UICollectionView, didSelectItemAt indexPath: IndexPath) {
        self.getIndex(index: indexPath.row)
        let viewControllers : NSArray = [self.viewControllers[indexPath.row]]
        pageViewController.setViewControllers(viewControllers as? [UIViewController], direction: .forward, animated: false, completion: nil)
    }
    
    func getIndex(index : Int) {
        arrOfLine = [String]()
        for indexValue in 0..<agendaDataFeedModelArray.count {
            if indexValue == index {
                arrOfLine.append("YES")
            } else {
                arrOfLine.append("NO")
            }
        }
        agendaTopCollectionView.reloadData()
        let indexPath = IndexPath(item: index, section: 0)
        agendaTopCollectionView.scrollToItem(at: indexPath, at: .centeredHorizontally, animated: true)
    }
    
    internal func changeView(indexValue: Int) {
        self.getIndex(index: indexValue)
    }
}
