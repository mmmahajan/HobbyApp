//
//  AgendaSessionTableViewCell.swift
//  Marico
//
//  Created by Admin on 06/09/17.
//  Copyright © 2017 Admin. All rights reserved.
//

import UIKit

class AgendaSessionTableViewCell: UITableViewCell {

    @IBOutlet weak var speakerNameCount: UILabel!
    @IBOutlet weak var sessionStartTime: UIButton!
    @IBOutlet weak var sessionSpeakerNameLabel: UILabel!
    @IBOutlet weak var sessionNameLabel: UILabel!
    override func awakeFromNib() {
        super.awakeFromNib()
        // Initialization code
    }

    override func setSelected(_ selected: Bool, animated: Bool) {
        super.setSelected(selected, animated: animated)

        // Configure the view for the selected state
    }
    
}
