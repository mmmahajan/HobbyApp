//
//  AgendaSessionViewController.swift
//  Marico
//
//  Created by Admin on 06/09/17.
//  Copyright © 2017 Admin. All rights reserved.
//

import UIKit

@objc protocol AgendaSessionViewControllerDelegate {
    @objc optional func changeView(indexValue: Int)
}

class AgendaSessionViewController: BaseViewController {

    @IBOutlet var tableView: UITableView!
    var pageIndex = 0
    var eventId = ""
    var menuName = ""
    var delegate:AgendaSessionViewControllerDelegate?
    var arrOFSession = [AgendaSessionModel]()
    var arrOFSessionForFilter = [AgendaSessionModel]()
    @IBOutlet weak var agendaSessionTableView: UITableView!
    
    override func viewDidLoad() {
        super.viewDidLoad()
        let nib = UINib(nibName: AGENDA_SESSION_NIB, bundle: nil)
        agendaSessionTableView.register(nib, forCellReuseIdentifier: AGENDA_CELL)
        agendaSessionTableView.delegate = self
        agendaSessionTableView.dataSource = self
        agendaSessionTableView.estimatedRowHeight = 80
        hideNavigationBar()
        // Do any additional setup after loading the view.
    }
    
    override func viewWillAppear(_ animated: Bool) {
        self.delegate?.changeView!(indexValue: pageIndex)
    }
}

extension AgendaSessionViewController: UITableViewDataSource, UITableViewDelegate {
    
    func tableView(_ tableView: UITableView, heightForRowAt indexPath: IndexPath) -> CGFloat {
        return  UITableViewAutomaticDimension
    }
    
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return arrOFSession.count
    }
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        
        let cell = tableView.dequeueReusableCell(withIdentifier: AGENDA_CELL, for: indexPath) as! AgendaSessionTableViewCell
        self.parent
//        if speakerSearch.text != EMPTY_STRING {
            cell.sessionNameLabel.text = arrOFSession[indexPath.row].session_name
            cell.speakerNameCount.text = "+\(getSpeakerNameCount(arrayString: arrOFSession[indexPath.row].session_speaker_name!, cell: cell))"
            cell.sessionSpeakerNameLabel.text = arrOFSession[indexPath.row].session_speaker_name
            cell.sessionStartTime.setTitle(AppUtil.toHourAndMinFormatString(startTime: arrOFSession[indexPath.row].session_start_time!), for: .normal)
            cell.selectionStyle = .none
//        } else {
//            cell.sessionNameLabel.text = arrOFSession[indexPath.row].session_name
//            cell.speakerNameCount.text = "+\(getSpeakerNameCount(arrayString: arrOFSession[indexPath.row].session_speaker_name!, cell: cell))"
//            cell.sessionSpeakerNameLabel.text = arrOFSession[indexPath.row].session_speaker_name
//            cell.sessionStartTime.setTitle(AppUtil.toHourAndMinFormatString(startTime: arrOFSession[indexPath.row].session_start_time!), for: .normal)
//            cell.selectionStyle = .none
//        }
        return cell
    }
    
    func tableView(_ tableView: UITableView, didSelectRowAt indexPath: IndexPath) {
        let viewController = AgendaDetailsViewController(nibName: "AgendaDetailsViewController", bundle: nil)
        viewController.arrOfSessionData = [arrOFSession[indexPath.row]]
        navigationController?.pushViewController(viewController, animated: true)
    }
    
    func getSpeakerNameCount(arrayString: String, cell: AgendaSessionTableViewCell) -> Int {
        if arrayString == "" {
            cell.speakerNameCount.isHidden = true
            cell.sessionSpeakerNameLabel.isHidden = true
            return 0
        }
        let string = arrayString
        let stringArr = string.characters.split{$0 == ","}.map(String.init)
        if stringArr.count == 0 {
            return 0
        }
        return stringArr.count - 1
    }
}


extension AgendaSessionViewController: UISearchBarDelegate {
    func searchBar(_ searchBar: UISearchBar, textDidChange searchText: String) {
        if searchText == "" {
            agendaSessionTableView.reloadData()
        }
        let predicate = NSPredicate(format: "SELF CONTAINS %@", searchText)
        arrOFSessionForFilter = self.arrOFSession.filter { predicate.evaluate(with: $0.session_name) }
        agendaSessionTableView.reloadData()
    }
}
